package paquete.ambulancias;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    private static Conexion instancia;
    private Connection conexion;
    private String usuario = "root";
    private String contraseña = "E@e$l@c@d3m1s1";
    String bd = "tap";
    String ip = "localhost";
    String puerto = "3306";
    private String url = "jdbc:mysql://"+ip+":"+puerto+"/"+bd;

    private Conexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conexion = DriverManager.getConnection(url, usuario, contraseña);
           // JOptionPane.showMessageDialog(null, "Conexión exitosa");
        } catch (ClassNotFoundException ex) {
            throw new SQLException(ex);
        }
    }

    public static Conexion getInstancia() throws SQLException {
        if (instancia == null) {
            instancia = new Conexion();
        } else if (instancia.getConexion().isClosed()) {
            instancia = new Conexion();
        }
        return instancia;
    }

    public Connection getConexion() {
        return conexion;
    }
}
