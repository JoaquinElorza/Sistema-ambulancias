package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.SQLException;
import javax.swing.JComboBox;

public class CP {

   public int insertarCP (String CP, String estado, int idMunicipio){
       
       String consulta = "insert into cp (CP, ESTADO, ID_MUNICIPIO) values (?, ?, ?);";
       int ultimoIdCP=-1;
       
       try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)){
           
           ps.setString(1, CP);
           ps.setString(2, estado);
           ps.setInt(3, idMunicipio);
           ps.executeUpdate();
           
           try(ResultSet rs = ps.getGeneratedKeys()){
               if(rs.next()){
                   ultimoIdCP = rs.getInt(1);
               }
           }
           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar CP, error: " + e.toString());
       }
    return ultimoIdCP;
   }
   
   public int modificarCP(JTextField cp, String estado, int idCP){
       String consulta = "UPDATE cp SET cp.CP = ?, cp.ESTADO =? WHERE cp.idCP=?";
       String select = "SELECT cp.ID_MUNICIPIO FROM cp WHERE idCP = ?";
       int idMunicipio = -1;
       try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement psUpdate = conexion.prepareStatement(consulta);
             PreparedStatement psSelect = conexion.prepareStatement(select)) {
            
            psUpdate.setString(1, cp.getText());
            psUpdate.setString(2, estado);
            psUpdate.setInt(3, idCP);
            psUpdate.executeUpdate();
            
            psSelect.setInt(1, idCP);
            ResultSet rs = psSelect.executeQuery();
            
            if(rs.next()){
                idMunicipio = rs.getInt("ID_MUNICIPIO");
            }
           
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar cp, error: " + e.toString());
        }
       return idMunicipio;
   }
   
   public void comboEstados(JComboBox<String> comboBox){
        String consulta = "SELECT ESTADOS FROM estadoscbo";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("ESTADOS");
                comboBox.addItem(nombre);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "no se pudo llenar el combobox " + e.toString());
        }
    }
   
}

