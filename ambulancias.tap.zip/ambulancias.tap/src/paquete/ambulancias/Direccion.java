package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.SQLException;

public class Direccion {

    
    public int insertarDireccion(int idCP, int nExterior, String calle){
       
       String consulta = "INSERT INTO direccion (ID_CP, n_exterior, calle) VALUES (?, ?, ?);";
       int ultimoIdDireccion=-1;
       
       try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)){
           
           ps.setInt(1, idCP);
           ps.setInt(2,nExterior);
           ps.setString(3, calle);
           ps.executeUpdate();
           
           try(ResultSet rs = ps.getGeneratedKeys()){
               if(rs.next()){
                   ultimoIdDireccion = rs.getInt(1);
               }
           }
           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar direccion, error: " + e.toString());
       }
    return ultimoIdDireccion;
    }
    
    public int modificarDireccion(JTextField nExterior, JTextField calle, int idDireccion){
        String consulta = "UPDATE direccion d SET d.N_EXTERIOR = ?, d.CALLE = ? WHERE ID_DIRECCION = ?";
        String select = "SELECT d.ID_CP FROM direccion d WHERE ID_DIRECCION = ?";
        
        int idCP = -1;
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement psUpdate = conexion.prepareStatement(consulta);
             PreparedStatement psSelect = conexion.prepareStatement(select)) {
            
            psUpdate.setString(1, nExterior.getText());
            psUpdate.setString(2, calle.getText());
            psUpdate.setInt(3, idDireccion);
            psUpdate.executeUpdate();

            psSelect.setInt(1,idDireccion);
            ResultSet rs = psSelect.executeQuery();
            
            if(rs.next()){
                idCP = rs.getInt("ID_CP");
            }
                    
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar dirección, error: " + e.toString());
        }
        return idCP;
    }
    
}
