package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;



public class paramedico {

    public void insertarParamedico(String gradoEstudios, String idPersonal) {
        String consulta = "INSERT INTO paramedico (GRADO_ESTUDIOS, ID_PERSONAL) VALUES (?, ?);";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {

            ps.setString(1, gradoEstudios);
            ps.setString(2, idPersonal);
            ps.execute();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar paramedico, Error: " + e.toString());
        }
    }
    
    public void seleccionarParamedico(JTable tbPersonal,JLabel id, JTextField nombre, JTextField paterno, JTextField materno, JTextField año,
            JTextField mes, JTextField dia, JRadioButton hombre, JRadioButton mujer, JTextField telefono, JTextField calle,
            JTextField nExterior, JTextField municipio, JTextField cp, JComboBox estado, JTextField curp,
            JTextField nss, JTextField licenciaEstudios){
        try{
            
            String consulta = """
                              SELECT pa.ID_PARAMEDICO, pa.GRADO_ESTUDIOS, 
                              p.CURP, p.NSS, P.NOMBRE, P.APELLIDO_PATERNO, P.APELLIDO_MATERNO, P.FECHA_NACIMIENTO,
                              t.TELEFONO_PERSONAL,
                              d.CALLE, d.N_EXTERIOR,
                              c.CP, c.ESTADO,
                              m.NOMBRE_MUNICIPIO
                              FROM paramedico pa
                              LEFT JOIN personal p ON pa.ID_PERSONAL = p.CURP
                              LEFT JOIN direccion d ON p.ID_DIRECCION = d.ID_DIRECCION
                              LEFT JOIN cp c ON d.ID_CP = c.idCP
                              LEFT JOIN municipio m ON c.ID_MUNICIPIO = m.idmunicipio
                              LEFT JOIN telefono t ON p.ID_TELEFONO = t.ID_TELEFONO""";
                                
            try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
            
            
            id.setText(rs.getString("ID_PARAMEDICO"));
            licenciaEstudios.setText(rs.getString("GRADO_ESTUDIOS"));
            curp.setText(rs.getString("CURP"));
            nss.setText(rs.getString("NSS"));
            nombre.setText(rs.getString("NOMBRE"));
            paterno.setText(rs.getString("APELLIDO_PATERNO"));
            materno.setText(rs.getString("APELLIDO_MATERNO"));
            
            año.setText(rs.getString("FECHA_NACIMIENTO").substring(0,3));
            mes.setText(rs.getString("FECHA_NACIMIENTO").substring(5, 6));
            dia.setText(rs.getString("FECHA_NACIMIENTO").substring(7, 8));
            
            telefono.setText(rs.getString("TELEFONO_PERSONAL"));
            calle.setText(rs.getString("CALLE"));
            nExterior.setText(rs.getString("N_EXTERIOR"));
            cp.setText(rs.getString("CP"));
            estado.setSelectedItem(rs.getString("ESTADO"));
            municipio.setText(rs.getString("NOMBRE_MUNICIPIO"));
            
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudo hacer el select para el seleccionar, error: " + e.toString());
    }

        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error de selcción, error: " + e.toString());
        }
        
    }
    
    public void modificarParamedico(JTextField estudios, String curp){
        String consulta = "UPDATE paramedico pa SET pa.GRADO_ESTUDIOS = ? WHERE ID_PERSONAL = ?";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, estudios.getText());
            ps.setString(2, curp);
            ps.executeUpdate(); 
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar paramedico, error: " + e.toString());
        }
    }
    
    public void eliminarParamedico(JTextField curp){
        String consulta = "DELETE FROM paramedico WHERE paramedico.ID_PERSONAL = ?;";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, curp.getText());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar paramedico, error: " + e.toString());
        }
        
    }
    
    public void cboParamedicos(JComboBox<String> comboBox) {
        String consulta = "select p.NOMBRE, p.APELLIDO_PATERNO, p.APELLIDO_MATERNO\n" +
"FROM personal p\n" +
"JOIN paramedico pa ON p.CURP = pa.ID_PERSONAL;";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("NOMBRE") + " " + rs.getString("APELLIDO_PATERNO") + " " + rs.getString("APELLIDO_MATERNO");
                comboBox.addItem(nombre);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public int idParamedico(JComboBox<String> nombre) {
    String consulta = "SELECT ID_PARAMEDICO \n" +
"FROM paramedico p\n" +
"JOIN personal pe  ON pe.CURP = p.ID_PERSONAL\n" +
"WHERE pe.NOMBRE + ' ' + pe.APELLIDO_PATERNO + ' ' +  pe.APELLIDO_MATERNO=?";
    
    int idParamedico = -1;

    // Obtener el nombre seleccionado del JComboBox
    String nombreSeleccionado = (String) nombre.getSelectedItem();
    
    // Verificar que el nombre seleccionado no sea nulo
    if (nombreSeleccionado == null) {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona un paramedico.");
        return idParamedico;
    }

    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement ps = conexion.prepareStatement(consulta)) {

        ps.setString(1, nombreSeleccionado);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                idParamedico = rs.getInt("ID_PARAMEDICO");
            }
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "No se pudo obtener el idParamedico, error: " + e.toString());
    }

    return idParamedico;
}
    
}
