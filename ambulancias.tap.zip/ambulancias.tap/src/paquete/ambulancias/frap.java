package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class frap {
    
String[] datos = new String[7];
    
    public void insertarFrap(int paciente, String fecha, String hora, int operador, String padecimiento, int paramedico){
        String consulta = "INSERT INTO frap(ID_PACIENTE,FECHA,HORA,ID_OPERADOR,PADECIMIENTO,ID_PARAMEDICO) VALUES (?,?,?,?,?,?)";
        
        try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta)){
           
           ps.setInt(1, paciente);
           ps.setString(2, fecha);
           ps.setString(3, hora);
           ps.setInt(4, operador);
           ps.setString(5, padecimiento);
           ps.setInt(6, paramedico);
           ps.executeUpdate();
           
       }catch (Exception e){
           System.out.println("eeeffff " + e.toString());
           JOptionPane.showMessageDialog(null, "error al insertar frap, error: " + e.toString());
       }
    }
    
    public void mostrarFrap(JTable tbFrap){
        
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tbFrap.setRowSorter(ordenarTabla);
        
        String consulta = " f.FECHA," +
"       pac.NOMBRE AS Paciente_Nombre, pac.APELLIDO_PATERNO AS Paciente_Apellido_Paterno, pac.APELLIDO_MATERNO AS Paciente_Apellido_Materno,\n" +
"       FROM frap f\n" +
"JOIN paciente pac ON f.ID_PACIENTE = pac.idpaciente\n";
        
        
        modelo.addColumn("Fecha");
        modelo.addColumn("Paciente");
        
        tbFrap.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
                String[] datosM = new String [2];
                datosM [0]= rs.getString("FECHA");
                datosM [1]= rs.getString("Paciente_Nombre") + " " + rs.getString("Paciente_Apellido_Paterno") + " " + rs.getString("Paciente_Apellido_Materno");
                
                modelo.addRow(datosM);
                
                tbFrap.setModel(modelo);
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudieron mostrar los registros de frap, error: " + e.toString());
    }
    }
    
    public void seleccionarFrap(JTable tbFrap, JLabel id, JTextField año, JTextField mes, JTextField dia, JTextField hora,
            JTextField minuto, JTextField padecimiento, JComboBox paciente, JComboBox paramedico, JComboBox operador){
        try{

        
            String consulta = "SELECT f.ID_FRAP, f.FECHA, f.HORA, f.PADECIMIENTO,\n" +
"       pac.NOMBRE AS Paciente_Nombre, pac.APELLIDO_PATERNO AS Paciente_Apellido_Paterno, pac.APELLIDO_MATERNO AS Paciente_Apellido_Materno,\n" +
"       par_per.NOMBRE AS Paramedico_Nombre, par_per.APELLIDO_PATERNO AS Paramedico_Apellido_Paterno, par_per.APELLIDO_MATERNO AS Paramedico_Apellido_Materno,\n" +
"       op_per.NOMBRE AS Operador_Nombre, op_per.APELLIDO_PATERNO AS Operador_Apellido_Paterno, op_per.APELLIDO_MATERNO AS Operador_Apellido_Materno\n" +
"FROM frap f\n" +
"JOIN paciente pac ON f.ID_PACIENTE = pac.idpaciente\n" +
"JOIN paramedico par ON f.ID_PARAMEDICO = par.ID_PARAMEDICO\n" +
"JOIN operador o ON f.ID_OPERADOR = o.ID_OPERADOR\n" +
"JOIN personal par_per ON par.ID_PERSONAL = par_per.CURP\n" +
"JOIN personal op_per ON o.ID_PERSONAL = op_per.CURP";
            
            try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) { 
                

            id.setText(rs.getString("ID_FRAP"));
            año.setText(rs.getString("FECHA").substring(0,4));
            mes.setText(rs.getString("FECHA").substring(5,7));
            dia.setText(rs.getString("FECHA").substring(8,10 ));
            hora.setText(rs.getString("HORA").substring(0, 2));
            minuto.setText(rs.getString("HORA").substring(3, 5));
            padecimiento.setText(rs.getString("PADECIMIENTO"));
            paciente.setSelectedItem(rs.getString("Paciente_Nombre") + " " + rs.getString("Paciente_Apellido_Paterno") + " " + rs.getString("Paciente_Apellido_Materno"));
            paramedico.setSelectedItem(rs.getString("Paramedico_Nombre") + " " + rs.getString("Paramedico_Apellido_Paterno") + " " + rs.getString("Paramedico_Apellido_Materno"));
            operador.setSelectedItem(rs.getString("Operador_Nombre") + " " + rs.getString("Operador_Apellido_Paterno") + " " + rs.getString("Operador_Apellido_Materno"));
                        
        
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudo hacer el select para el seleccionar, error: " + e.toString());
    }
            
         }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Error al seleciconar la frap: " + e.toString());
                }
    }
    
    public void modificarFrap(int paciente, JTextField año, JTextField mes, JTextField dia, JTextField hora, JTextField minuto,
            int operador, JTextField padecimiento, int paramedico, JLabel id){
        String consulta = "update frap set ID_PACIENTE=?, FECHA=?, HORA=?, ID_OPERADOR=?,PADECIMIENTO=?,ID_PARAMEDICO=? where ID_FRAP=?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement psUpdate = conexion.prepareStatement(consulta)) {
            
            psUpdate.setInt(1, paciente);
            psUpdate.setString(2, año.getText() + "-" + mes.getText() + "-" + dia.getText());
            psUpdate.setString(3, hora.getText() + ":" + minuto.getText());
            psUpdate.setInt(4, operador);
            psUpdate.setString(5, padecimiento.getText());
            psUpdate.setInt(6, paramedico);
            psUpdate.setInt(7, Integer.parseInt(id.getText()));
            psUpdate.executeUpdate();

        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo modificar el hospital, error: " + e.toString());
    }
    } 
        
    public void eliminarFrap(JLabel id){
        String consulta = "DELETE FROM frap WHERE ID_FRAP=?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, id.getText());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar frap, error: " + e.toString());
        }
    }
    
}