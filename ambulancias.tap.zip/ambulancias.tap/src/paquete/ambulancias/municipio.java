package paquete.ambulancias;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTextField;

public class municipio {

    public int insertarMunicipio(String nombreMunicipio) {
        String consulta = "INSERT INTO municipio (NOMBRE_MUNICIPIO) VALUES (?);";
        int ultimoId = -1; // Inicializar con un valor que indique un error por defecto
        
        try (Connection conexion = Conexion.getInstancia().getConexion(); 
             PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)) {
             
            ps.setString(1, nombreMunicipio);
            ps.executeUpdate();
            
            // Obtener el último ID creado
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    ultimoId = rs.getInt(1);
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar municipio, Error: " + e.toString());
        }
        
        return ultimoId; // Retorna el ID del último registro insertado
    }
    
    public void modificarMunicipio(JTextField nombreMunicipio, int idMunicipio){
        String consulta = "UPDATE municipio m SET m.NOMBRE_MUNICIPIO = ? WHERE m.idmunicipio = ?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, nombreMunicipio.getText());
            ps.setInt(2, idMunicipio);
            ps.executeUpdate();

            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar municipio, error: " + e.toString());
        }
    }
}

