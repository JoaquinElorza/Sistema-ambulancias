package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;


public class paciente {
    public void insertarPaciente(int idDomicilio, JTextField ocupacion, JTextField edad, int derechohabiente, JTextField responsable,
            JTextField nombre, JTextField paterno, JTextField materno, String genero){
            String consulta = "INSERT INTO paciente (ID_DOMICILIO, OCUPACION, EDAD, DERECHOHABIENTE, RESPONSABLE, NOMBRE, APELLIDO_PATERNO,\n" +
"APELLIDO_MATERNO, GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            
        try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta)){
           
           ps.setInt(1, idDomicilio);
           ps.setString(2, ocupacion.getText());
           ps.setString(3, edad.getText());
           ps.setInt(4, derechohabiente);
           ps.setString(5, responsable.getText());
           ps.setString(6, nombre.getText());
           ps.setString(7, paterno.getText());
           ps.setString(8, materno.getText());
           ps.setString(9, genero);
           
           ps.executeUpdate();
           

           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar paciente, error: " + e.toString());
       }
    }
    
    public void mostrarPaciente(JTable tbPacientes){
        
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tbPacientes.setRowSorter(ordenarTabla);
        
        String consulta = "SELECT p.idpaciente, p.NOMBRE, p.APELLIDO_PATERNO, p.APELLIDO_MATERNO, p.GENERO, p.EDAD, p.OCUPACION, p.RESPONSABLE,\n" +
"h.NOMBRE,\n" +
"d.CALLE, d.N_EXTERIOR,\n" +
"m.NOMBRE_MUNICIPIO,\n" +
"C.ESTADO, c.CP\n" +
"FROM paciente p\n" +
"JOIN hospital h ON p.DERECHOHABIENTE = h.idhospital\n" +
"JOIN direccion d ON p.ID_DOMICILIO = d.ID_DIRECCION\n" +
"JOIN cp c ON d.ID_CP = c.idCP\n" +
"JOIN municipio m ON c.ID_MUNICIPIO = m.idmunicipio;";
        
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido Paterno");
        modelo.addColumn("Apellido Materno");
        modelo.addColumn("Genero");
        modelo.addColumn("Edad");
        modelo.addColumn("Ocupacion");
        modelo.addColumn("Responsable");
        modelo.addColumn("Derechohabiente");
        modelo.addColumn("Calle");
        modelo.addColumn("Numero");
        modelo.addColumn("Municipio");
        modelo.addColumn("Estado");
        modelo.addColumn("CP");
        
        tbPacientes.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
                String[] datos = new String[14];
                datos[0]=rs.getString("idpaciente");
                datos[1] = rs.getString("NOMBRE");
                datos[2] = rs.getString("APELLIDO_PATERNO");
                datos[3] = rs.getString("APELLIDO_MATERNO");
                datos[4] = rs.getString("GENERO");
                datos[5] = rs.getString("EDAD");
                datos[6] = rs.getString("OCUPACION");
                datos[7] = rs.getString("RESPONSABLE");
                datos[8] = rs.getString("NOMBRE");
                datos[9] = rs.getString("CALLE");
                datos[10] = rs.getString("N_EXTERIOR");
                datos[11] = rs.getString("NOMBRE_MUNICIPIO");
                datos[12] = rs.getString("ESTADO");
                datos[13] = rs.getString("CP");
                modelo.addRow(datos);
                
                tbPacientes.setModel(modelo);
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudieron mostrar los registros de pacientes, error: " + e.toString());
    }
    }
    
    public void seleccionarPaciente(JTable tbP, JLabel id, JTextField nombre, JTextField paterno, JTextField materno, JTextField edad,
            JRadioButton hombre, JRadioButton mujer, JTextField ocupacion, JComboBox derechohabiente, JTextField responsable,
            JTextField calle, JTextField nexterior, JTextField municipio, JComboBox estado, JTextField cp){
        
        try{
            int fila = tbP.getSelectedRow();
            
            if (fila>=0){
                id.setText(tbP.getValueAt(fila,0).toString());
                nombre.setText(tbP.getValueAt(fila, 1).toString());
                paterno.setText(tbP.getValueAt(fila, 2).toString());
                materno.setText(tbP.getValueAt(fila, 3).toString());
                if(tbP.getValueAt(fila, 4).toString().equals("H")){
                    hombre.setSelected(true);
                }else{
                    mujer.setSelected(true);
                }
                edad.setText(tbP.getValueAt(fila, 5).toString());
                ocupacion.setText(tbP.getValueAt(fila, 6).toString());
                responsable.setText(tbP.getValueAt(fila, 7).toString());
                derechohabiente.setSelectedItem(tbP.getValueAt(fila, 8).toString());
                calle.setText(tbP.getValueAt(fila, 9).toString());
                nexterior.setText(tbP.getValueAt(fila, 10).toString());
                municipio.setText(tbP.getValueAt(fila, 11).toString());
                estado.setSelectedItem(tbP.getValueAt(fila, 12).toString());
                cp.setText(tbP.getValueAt(fila, 13).toString());
                
            }
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pudo seleccionar: " + e.toString());
        }
    }
           
    public int modificarPaciente(JTextField ocupacion, JLabel id, JTextField edad, JTextField responsable,
            JTextField nombre, JTextField paterno, JTextField materno, String genero, String idPaciente){
 String consulta = "UPDATE paciente SET OCUPACION = ?, EDAD = ?, RESPONSABLE = ?, NOMBRE = ?, APELLIDO_PATERNO = ?, APELLIDO_MATERNO = ?,\n" +
" GENERO = ? WHERE idpaciente = ?";

    String select = "select ID_DOMICILIO from paciente WHERE idpaciente=?";
            
    int idDireccion = -1;
        try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta);
           PreparedStatement psSelect = conexion.prepareStatement(select) ){
           
           ps.setString(1, ocupacion.getText());
           ps.setString(2, edad.getText());
           ps.setString(3, responsable.getText());
           ps.setString(4, nombre.getText());
           ps.setString(5, paterno.getText());
           ps.setString(6, materno.getText());
           ps.setString(7, genero);
           ps.setString(8, idPaciente);
           
           ps.executeUpdate();
           
           psSelect.setString(1, id.getText());
           ResultSet rs = psSelect.executeQuery();

           if(rs.next()){
               idDireccion = rs.getInt("ID_DOMICILIO");
           }
           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar paciente, error: " + e.toString());
       }
        return idDireccion;
    }
    
    public void eliminarPaciente(JLabel id){
        String consulta = "DELETE FROM paciente WHERE idpaciente = ?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setInt(1,Integer.parseInt(id.getText()));
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo eliminar el paciente, error: " + e.toString());
    }
    }
    
    public void cboPacientes(JComboBox<String> comboBox) {
        String consulta = "SELECT NOMBRE, APELLIDO_PATERNO, APELLIDO_MATERNO from paciente;";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("NOMBRE") + " " + rs.getString("APELLIDO_PATERNO") + " " + rs.getString("APELLIDO_MATERNO");
                comboBox.addItem(nombre);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public int idPaciente(JComboBox<String> nombre) {
    String consulta = "SELECT idpaciente FROM paciente WHERE NOMBRE + ' ' + APELLIDO_PATERNO + ' ' +  APELLIDO_MATERNO=?";
    int idPaciente = -1;

    // Obtener el nombre seleccionado del JComboBox
    String nombreSeleccionado = (String) nombre.getSelectedItem();
    
    // Verificar que el nombre seleccionado no sea nulo
    if (nombreSeleccionado == null) {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona un paciente.");
        return idPaciente;
    }

    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement ps = conexion.prepareStatement(consulta)) {

        ps.setString(1, nombreSeleccionado);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                idPaciente = rs.getInt("idpaciente");
            }
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "No se pudo obtener el idpaciente, error: " + e.toString());
    }

    return idPaciente;
}
    
 }
