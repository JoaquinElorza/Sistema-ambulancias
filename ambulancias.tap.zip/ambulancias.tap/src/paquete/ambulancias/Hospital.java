package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class Hospital {

    
    public Hospital (){}

    
    
    public void insertarHospital(int idDireccion, String nombre){
        String consulta = "insert into hospital (ID_DIRECCION, NOMBRE) values (?,?)";
       
        try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta)){
           
           ps.setInt(1, idDireccion);
           ps.setString(2, nombre);
           ps.executeUpdate();

           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar hospital, error: " + e.toString());
       }
    }
    
    public void mostrarHospitales(JTable tablaHospitales){
        String consulta = "select h.idhospital, h.NOMBRE,\n" +
"d.CALLE, d.N_EXTERIOR,\n" +
"m.NOMBRE_MUNICIPIO,\n" +
"cp.ESTADO, cp.CP\n" +
"FROM hospital h\n" +
"JOIN direccion d ON h.ID_DIRECCION = d.ID_DIRECCION\n" +
"JOIN cp ON d.ID_CP = cp.idCP\n" +
"JOIN municipio m ON cp.ID_MUNICIPIO = m.idmunicipio"; 
        
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tablaHospitales.setRowSorter(ordenarTabla);
        
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Calle");
        modelo.addColumn("N calle");
        modelo.addColumn("Municipio");
        modelo.addColumn("Estado");
        modelo.addColumn("CP");
        
        tablaHospitales.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
                String[] datos = new String[7];
                datos[0] = rs.getString("idhospital");
                datos[1] = rs.getString("NOMBRE");
                datos[2] = rs.getString("CALLE");
                datos[3] = rs.getString("N_EXTERIOR");
                datos[4] = rs.getString("NOMBRE_MUNICIPIO");
                datos[5] = rs.getString("ESTADO");
                datos[6] = rs.getString("CP");
                modelo.addRow(datos);
                
                tablaHospitales.setModel(modelo);
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudieron mostrar los hospitales, error: " + e.toString());
    }
    }
    
    public void seleccionarHospital(JTable tbH, JLabel id, JTextField nombre, JTextField calle, JTextField numero,
            JTextField municipio, JComboBox estado, JTextField cp){
        
        try{
            int fila= tbH.getSelectedRow();
            
            if(fila>=0){
                id.setText(tbH.getValueAt(fila, 0).toString());
                nombre.setText(tbH.getValueAt(fila, 1).toString());
                calle.setText(tbH.getValueAt(fila, 2).toString());
                numero.setText(tbH.getValueAt(fila, 3).toString());
                municipio.setText(tbH.getValueAt(fila, 4).toString());
                estado.setSelectedItem(tbH.getValueAt(fila, 5));
                cp.setText(tbH.getValueAt(fila, 6).toString());
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "no se pudieron mostrar los registros, error: " + e.toString());
        }
    }
    
    public int modificarHospital(JTextField nombre, JLabel id){
        String consulta = "UPDATE hospital h SET NOMBRE = ? WHERE idhospital = ?";
        String select = "select h.ID_DIRECCION from hospital h WHERE idhospital = ?";
        int idDireccion = -1;
            try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement psUpdate = conexion.prepareStatement(consulta);
             PreparedStatement psSelect = conexion.prepareStatement(select)) {
            
            psUpdate.setString(1, nombre.getText());
            psUpdate.setInt(2, Integer.parseInt(id.getText()));
            psUpdate.executeUpdate();
            
            psSelect.setInt(1, Integer.parseInt(id.getText()));
            ResultSet rs = psSelect.executeQuery();
            
            if(rs.next()){
                idDireccion = rs.getInt("ID_DIRECCION");
            }
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo modificar el hospital, error: " + e.toString());
    }
            return idDireccion;
    }
    
    public void eliminarHospital(JLabel id){
        String consulta = "DELETE FROM hospital WHERE idhospital = ?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setInt(1,Integer.parseInt(id.getText()));
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo eliminar el hospital, error: " + e.toString());
    }
    }
    
    public void cboHospitales(JComboBox<String> comboBox) {
        String consulta = "select NOMBRE from hospital";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("NOMBRE");
             //   int id = rs.getInt("idhospital");
                comboBox.addItem(nombre);
              //  hos.add(new Hospital(id, nombre));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
public int idHospital(JComboBox<String> nombre) {
    String consulta = "SELECT idhospital FROM hospital WHERE NOMBRE = ?";
    int idHospital = -1;

    // Obtener el nombre seleccionado del JComboBox
    String nombreSeleccionado = (String) nombre.getSelectedItem();
    
    // Verificar que el nombre seleccionado no sea nulo
    if (nombreSeleccionado == null) {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona un hospital.");
        return idHospital;
    }

    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement ps = conexion.prepareStatement(consulta)) {

        ps.setString(1, nombreSeleccionado);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                idHospital = rs.getInt("idhospital");
            }
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "No se pudo obtener el idHospital, error: " + e.toString());
    }

    return idHospital;
}

    }