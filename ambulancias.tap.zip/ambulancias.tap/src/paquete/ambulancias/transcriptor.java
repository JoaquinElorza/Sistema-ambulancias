package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;

public class transcriptor {

    public int insertarTrans(String usuario, String contraseña, String administrador) {

        String consulta = "INSERT INTO transcriptor (USUARIO, CONTRASEÑA, ADMINISTRADOR) VALUES (?,?,?);";
        int ultimoIdCP = -1;

        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, usuario);
            ps.setString(2, contraseña);
            ps.setString(3, administrador);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    ultimoIdCP = rs.getInt(1);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar transcriptor, error: " + e.toString());
        }
        return ultimoIdCP;
    }

    public void mostrarTrans(JTable tablaTrans) {
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tablaTrans.setRowSorter(ordenarTabla);

        String sql = "SELECT * FROM transcriptor;";

      //  modelo.addColumn("ID");
        modelo.addColumn("ID");
        modelo.addColumn("Usuario");
        modelo.addColumn("Contraseña");
        modelo.addColumn("Administrador");

        tablaTrans.setModel(modelo);

        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String[] datos = new String[4];
                datos[0] = rs.getString("ID_TRANSCRIPTOR");
                datos[1] = rs.getString("USUARIO");
                datos[2] = rs.getString("CONTRASEÑA");
                datos[3] = rs.getString("ADMINISTRADOR");
                modelo.addRow(datos);
            }

            tablaTrans.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudieron mostrar los registros, error: " + e.toString());
        }
    }
    
    
    public void seleccionarCapturista(JTable tablaTrans,JTextField id, JTextField nombre, JTextField contraseña, JRadioButton admin, JRadioButton noadmin){
        try{
            int fila = tablaTrans.getSelectedRow();
            
            if(fila>=0){
                id.setText(tablaTrans.getValueAt(fila, 0).toString());
                nombre.setText((String)tablaTrans.getValueAt(fila, 1));
                contraseña.setText((String)tablaTrans.getValueAt(fila, 2));
                if(tablaTrans.getValueAt(fila, 3).equals("S")){
                    admin.setSelected(true);
                }else{
                    noadmin.setSelected(true);
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Errr de selcción, error: " + e.toString());
        }
    }
    
    public void modificarCapturista(JTextField usuario, JTextField contraseña, JRadioButton admin, JTextField id){
        String consulta = "UPDATE transcriptor SET transcriptor.USUARIO = ? , transcriptor.CONTRASEÑA = ? , transcriptor.ADMINISTRADOR = ? WHERE transcriptor.ID_TRANSCRIPTOR = ?;";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, usuario.getText());
            ps.setString(2, contraseña.getText());
            ps.setString(3, admin.isSelected() ? "S" : "N");
            ps.setInt(4, Integer.parseInt(id.getText()));
            ps.executeUpdate();

            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar capturista, error: " + e.toString());
        }
        
    }
    
    public void eliminarCapturista(JTextField id){
        String consulta ="DELETE FROM transcriptor WHERE transcriptor.ID_TRANSCRIPTOR = ?;";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setInt(1, Integer.parseInt(id.getText()));
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar capturista, error: " + e.toString());
        }
        
    }
    
    public String iniciarSesion(JTextField usuario, JTextField contraseña) {
    String consulta = "SELECT ADMINISTRADOR FROM transcriptor WHERE USUARIO = ? AND CONTRASEÑA = ?;";
    String admin = ""; // Valor por defecto si no se encuentra el usuario
    
    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement ps = conexion.prepareStatement(consulta)) {
        
        // Configura los parámetros de la consulta
        ps.setString(1, usuario.getText());
        ps.setString(2, contraseña.getText());
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            // Obtiene el ID_TRANSCRIPTOR del ResultSet
            admin = rs.getString("ADMINISTRADOR");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al iniciar sesión, error: " + e.toString());
    }
    
    return admin;
}

}

