package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class Operador{
    public void insertarOperador(String licencia, String idPersonal) {
        String consulta = "INSERT INTO operador (LICENCIA, ID_PERSONAL) VALUES (?,?);";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {

            ps.setString(1, licencia);
            ps.setString(2, idPersonal);
            ps.execute();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar operador, Error: " + e.toString());
        }
    }
    
    public void modificarOperador(JTextField licencia, String curp){
        String consulta = "UPDATE operador o SET o.LICENCIA = ? WHERE ID_PERSONAL = ?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, licencia.getText());
            ps.setString(2, curp);
            ps.executeUpdate();

            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar operador, error: " + e.toString());
        }
    }
    
    public void eliminarOperador(JTextField curp){
        String consulta = "DELETE FROM operador WHERE operador.ID_PERSONAL = ?;";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, curp.getText());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar operador, error: " + e.toString());
        }
    }
    
    public void cboOperadoress(JComboBox<String> comboBox) {
        String consulta = "select p.NOMBRE, p.APELLIDO_PATERNO, p.APELLIDO_MATERNO\n" +
"FROM personal p\n" +
"JOIN operador o ON p.CURP = o.ID_PERSONAL;";
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("NOMBRE") + " " + rs.getString("APELLIDO_PATERNO") + " " + rs.getString("APELLIDO_MATERNO");
                comboBox.addItem(nombre);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public int idOperador (JComboBox<String> nombre) {
    String consulta = "SELECT ID_OPERADOR\n" +
"FROM operador o\n" +
"JOIN personal p  ON p.CURP = o.ID_PERSONAL\n" +
"WHERE p.NOMBRE + ' ' + p.APELLIDO_PATERNO + ' ' +  p.APELLIDO_MATERNO=?";
    int idOperador = -1;

    // Obtener el nombre seleccionado del JComboBox
    String nombreSeleccionado = (String) nombre.getSelectedItem();
    
    // Verificar que el nombre seleccionado no sea nulo
    if (nombreSeleccionado == null) {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona un operador.");
        return idOperador;
    }

    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement ps = conexion.prepareStatement(consulta)) {

        ps.setString(1, nombreSeleccionado);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                idOperador = rs.getInt("ID_OPERADOR");
            }
        }
        
    } catch (Exception e) {
        System.out.println(e.toString());
        JOptionPane.showMessageDialog(null, "No se pudo obtener el idOperador, error: " + e.toString());
    }

    return idOperador;
}
    
}
