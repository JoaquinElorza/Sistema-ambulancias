package paquete.ambulancias;

import java.util.Random;

public class GeneradorCurp {
    
    
    
    public static String generarCurp(String nombre, String apellidoP, String apellidoM, String anio, String mes, String dia,
            String genero, String estado) {
        nombre = nombre.toUpperCase();
        apellidoP = apellidoP.toUpperCase();
        apellidoM = apellidoM.toUpperCase();
        genero = genero.toUpperCase();
        estado = estado.toUpperCase();

        char primerCaracterAp = apellidoP.charAt(0);
        char segundoCaracterAp = encontrarPrimeraVocal(apellidoP);
        char primerCaracterAm = apellidoM.charAt(0);
        char primerCaracterNombre = nombre.charAt(0);

        char primeraConsonanteAp = obtenerPrimeraConsonante(apellidoP);
        char primeraConsonanteAm = obtenerPrimeraConsonante(apellidoM);
        char primeraConsonanteNombre = obtenerPrimeraConsonante(nombre);

        Random random = new Random();
        int uno = random.nextInt(10);
        int dos = random.nextInt(10);

        String curpGenerada = "" + primerCaracterAp + segundoCaracterAp + primerCaracterAm + primerCaracterNombre +
                anio.substring(2) + mes + dia + genero + estado.substring(0, 2) +
                primeraConsonanteAp + primeraConsonanteAm + primeraConsonanteNombre + uno + dos;

        return curpGenerada;
    }

    private static char obtenerPrimeraConsonante(String texto) {
        char[] consonantes = {'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'Ñ', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z'};
        char[] vocales = {'A', 'E', 'I', 'O', 'U'};
        texto = texto.toUpperCase();
        boolean primeraVocalEncontrada = false;

        for (int i = 0; i < texto.length(); i++) {
            char letra = texto.charAt(i);
            if (!primeraVocalEncontrada) {
                for (char vocal : vocales) {
                    if (letra == vocal) {
                        primeraVocalEncontrada = true;
                        break;
                    }
                }
            } else {
                for (char consonante : consonantes) {
                    if (letra == consonante) {
                        return letra;
                    }
                }
            }
        }
        return '\0';
    }

    private static char encontrarPrimeraVocal(String texto) {
        char[] vocales = {'A', 'E', 'I', 'O', 'U'};
        texto = texto.toUpperCase();

        for (int i = 0; i < texto.length(); i++) {
            char letra = texto.charAt(i);
            for (char vocal : vocales) {
                if (letra == vocal) {
                    return letra;
                }
            }
        }
        return '\0';
    }

}
