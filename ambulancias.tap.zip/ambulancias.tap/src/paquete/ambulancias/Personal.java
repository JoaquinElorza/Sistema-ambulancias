package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class Personal {
  
    public String insertarPersonal (String CURP, String NSS, String nombre, String aPaterno, String  aMaterno, String fNacimiento, int idDireccion, int idTelefono){
       
       String consulta = "INSERT INTO personal (CURP, NSS, NOMBRE, APELLIDO_PATERNO, APELLIDO_MATERNO, FECHA_NACIMIENTO, ID_DIRECCION, ID_TELEFONO) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
       
       try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)){
           
           ps.setString(1, CURP);
           ps.setString(2, NSS);
           ps.setString(3, nombre);
           ps.setString(4, aPaterno);
           ps.setString(5, aMaterno);
           ps.setString(6, fNacimiento);
           ps.setInt(7,idDireccion);
           ps.setLong(8, idTelefono);
           ps.executeUpdate();
           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar Personal, error: " + e.toString());
       }
    return CURP;
    }
    
    public void mostrarOperadores(JTable tbPersonal){
     DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tbPersonal.setRowSorter(ordenarTabla);

        String consulta = "P.NOMBRE, P.APELLIDO_PATERNO, P.APELLIDO_MATERNO,\n" +
"FROM operador o\n" +
"JOIN personal p ON o.ID_PERSONAL = p.CURP\n";

        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido paterno");
        modelo.addColumn("Apellido materno");

        
        tbPersonal.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
                String[] datos = new String[3];

                datos[0] = rs.getString("NOMBRE");
                datos[1] = rs.getString("APELLIDO_PATERNO");
                datos[2] = rs.getString("APELLIDO_MATERNO");
                
                modelo.addRow(datos);
                
                tbPersonal.setModel(modelo);
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudieron mostrar los registros, error: " + e.toString());
    }
    }
    
    public void seleccionarOperador(JTable tbPersonal,JLabel id, JTextField nombre, JTextField paterno, JTextField materno, JTextField año,
            JTextField mes, JTextField dia, JRadioButton hombre, JRadioButton mujer, JTextField telefono, JTextField calle,
            JTextField nExterior, JTextField municipio, JTextField cp, JComboBox estado, JTextField curp,
            JTextField nss, JTextField licenciaEstudios){
        try{
            
            String consulta = """
                              SELECT o.ID_OPERADOR, o.LICENCIA,
                              p.CURP, p.NSS, P.NOMBRE, P.APELLIDO_PATERNO, P.APELLIDO_MATERNO, P.FECHA_NACIMIENTO,
                              t.TELEFONO_PERSONAL,
                              d.CALLE, d.N_EXTERIOR,
                              c.CP, c.ESTADO,
                              m.NOMBRE_MUNICIPIO
                              FROM operador o
                              JOIN personal p ON o.ID_PERSONAL = p.CURP
                              JOIN direccion d ON p.ID_DIRECCION = d.ID_DIRECCION
                              JOIN cp c ON d.ID_CP = c.idCP
                              JOIN municipio m ON c.ID_MUNICIPIO = m.idmunicipio
                              JOIN telefono t ON p.ID_TELEFONO = t.ID_TELEFONO;""";
                                
            try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
            
            
            id.setText(rs.getString("ID_OPERADOR"));
            licenciaEstudios.setText(rs.getString("LICENCIA"));
            curp.setText(rs.getString("CURP"));
            nss.setText(rs.getString("NSS"));
            nombre.setText(rs.getString("NOMBRE"));
            paterno.setText(rs.getString("APELLIDO_PATERNO"));
            materno.setText(rs.getString("APELLIDO_MATERNO"));
            
            año.setText(rs.getString("FECHA_NACIMIENTO").substring(0,3));
            mes.setText(rs.getString("FECHA_NACIMIENTO").substring(5, 6));
            dia.setText(rs.getString("FECHA_NACIMIENTO").substring(7, 8));
            
            telefono.setText(rs.getString("TELEFONO_PERSONAL"));
            calle.setText(rs.getString("CALLE"));
            nExterior.setText(rs.getString("N_EXTERIOR"));
            cp.setText(rs.getString("CP"));
            estado.setSelectedItem(rs.getString("ESTADO"));
            municipio.setText(rs.getString("NOMBRE_MUNICIPIO"));
            
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudo hacer el select para el seleccionar, error: " + e.toString());
    }

        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error de selcción, error: " + e.toString());
        }
        
    }
    
    public void mostrarParamedicos(JTable tbPersonal){
     DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tbPersonal.setRowSorter(ordenarTabla);

        String consulta = "SELECT pa.ID_PARAMEDICO, pa.GRADO_ESTUDIOS,\n" +
"p.CURP, p.NSS, P.NOMBRE, P.APELLIDO_PATERNO, P.APELLIDO_MATERNO, P.FECHA_NACIMIENTO,\n" +
"t.TELEFONO_PERSONAL,\n" +
"d.CALLE, d.N_EXTERIOR,\n" +
"c.CP, c.ESTADO,\n" +
"m.NOMBRE_MUNICIPIO\n" +
"FROM paramedico pa\n" +
"LEFT JOIN personal p ON pa.ID_PERSONAL = p.CURP\n" +
"LEFT JOIN direccion d ON p.ID_DIRECCION = d.ID_DIRECCION\n" +
"LEFT JOIN cp c ON d.ID_CP = c.idCP\n" +
"LEFT JOIN municipio m ON c.ID_MUNICIPIO = m.idmunicipio\n" +
"LEFT JOIN telefono t ON p.ID_TELEFONO = t.ID_TELEFONO;";
        
        modelo.addColumn("ID");
        modelo.addColumn("Estudios");
        modelo.addColumn("CURP");
        modelo.addColumn("NSS");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido paterno");
        modelo.addColumn("Apellido materno");
        modelo.addColumn("Fecha de nacimiento");
        modelo.addColumn("Telefono");
        modelo.addColumn("Calle");
        modelo.addColumn("Numero exterior");
        modelo.addColumn("CP");
        modelo.addColumn("Estado");
        modelo.addColumn("Municipio");
        
        tbPersonal.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while (rs.next()) {
                String[] datos = new String[14];
                datos[0] = rs.getString("ID_PARAMEDICO");
                datos[1] = rs.getString("GRADO_ESTUDIOS");
                datos[2] = rs.getString("CURP");
                datos[3] = rs.getString("NSS");
                datos[4] = rs.getString("NOMBRE");
                datos[5] = rs.getString("APELLIDO_PATERNO");
                datos[6] = rs.getString("APELLIDO_MATERNO");
                datos[7] = rs.getString("FECHA_NACIMIENTO");
                datos[8] = rs.getString("TELEFONO_PERSONAL");
                datos[9] = rs.getString("CALLE");
                datos[10] = rs.getString("N_EXTERIOR");
                datos[11] = rs.getString("CP");
                datos[12] = rs.getString("ESTADO");
                datos[13] = rs.getString("NOMBRE_MUNICIPIO");
                modelo.addRow(datos);
                
                tbPersonal.setModel(modelo);
            }
            
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "no se pudieron mostrar los registros, error: " + e.toString());
    }
    }
    
     public int modificarPersonal(JTextField nss, JTextField nombre, JTextField paterno, JTextField materno, String fNacimiento, String curp) {
    String consulta = "UPDATE personal p SET p.NSS = ?, p.NOMBRE = ?, p.APELLIDO_PATERNO = ?, p.APELLIDO_MATERNO = ?, p.FECHA_NACIMIENTO = ? WHERE p.CURP = ?";
    String select = "SELECT p.ID_DIRECCION FROM personal p WHERE p.CURP = ?";
    int idDireccion = -1;

    try (Connection conexion = Conexion.getInstancia().getConexion();
         PreparedStatement psUpdate = conexion.prepareStatement(consulta);
         PreparedStatement psSelect = conexion.prepareStatement(select)) {
        
        // Configura los parámetros de la consulta de actualización
        psUpdate.setString(1, nss.getText());
        psUpdate.setString(2, nombre.getText());
        psUpdate.setString(3, paterno.getText());
        psUpdate.setString(4, materno.getText());
        psUpdate.setString(5, fNacimiento);
        psUpdate.setString(6, curp);
        psUpdate.executeUpdate();
        
        // Configura los parámetros de la consulta de selección
        psSelect.setString(1, curp);
        ResultSet rs = psSelect.executeQuery();
        
        // Obtiene el resultado de la consulta de selección
        if (rs.next()) {
            idDireccion = rs.getInt("ID_DIRECCION");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar personal, error: " + e.toString());
    }
    
    return idDireccion;
}

    public int idTelefono(String curp){
        String consulta = "SELECT p.ID_TELEFONO FROM personal p WHERE CURP=?";
        int idTelefono=-1;
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, curp);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                idTelefono = rs.getInt("ID_TELEFONO");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener idTelefono, error: " + e.toString());
        }
            return idTelefono;
    }
    
   public void eliminarOperador(JTextField id){
       String consulta = "DELETE FROM operador WHERE ID_OPERADOR = ?";
       
       try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setInt(1,Integer.parseInt(id.getText()));
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo eliminar el operador, error: " + e.toString());
    }
   }
}
