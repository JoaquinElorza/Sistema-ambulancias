package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class ambulancia {
    
    public void cboAmbulancias(JComboBox cboTipo){
        String consulta = "SELECT tipo_hambulancia FROM tipo_hambulancia";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("tipo_hambulancia");
                cboTipo.addItem(nombre);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "no se pudo llenar el combobox de ambulancias " + e.toString());
        }
    }
            
            
    public int insertarAmbulancia(String placa, String tipo, String capacidad, String año){
        String consulta = "INSERT  INTO  ambulancia (PLACA, TIPO, CAPACIDAD, AÑO) VALUES (?,?,?,?)";
        String select = "SELECT a.ID_AMBULANCIA FROM ambulancia a WHERE PLACA = ?;";
        
        int idAmbulancia = -1;
        
        try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta);
                PreparedStatement psSelect = conexion.prepareStatement(select)){
           
           ps.setString(1, placa);
           ps.setString(2, tipo);
           ps.setString(3, capacidad);
           ps.setString(4, año);
           ps.executeUpdate();
           
           psSelect.setString(1, placa);
           ResultSet rs = psSelect.executeQuery();
           
           if(rs.next()){
               idAmbulancia = rs.getInt("ID_AMBULANCIA");
           }

           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar ambulancia, error: " + e.toString());
       }
        return idAmbulancia;
    }
    
    public void mostrarAmbulancias(JTable tbA){
        String consulta = "SELECT * FROM ambulancia";
        
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
        tbA.setRowSorter(ordenarTabla);
        
        modelo.addColumn("ID");
        modelo.addColumn("Placa");
        modelo.addColumn("Tipo");
        modelo.addColumn("Capacidad");
        modelo.addColumn("Año");
        tbA.setModel(modelo);
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {
            
            while(rs.next()){
                String[] datos = new String[5];
                datos[0]=rs.getString("ID_AMBULANCIA");
                datos[1]=rs.getString("PLACA");
                datos[2]=rs.getString("TIPO");
                datos[3]=rs.getString("CAPACIDAD");
                datos[4]=rs.getString("AÑO");
                
                modelo.addRow(datos);
                
                tbA.setModel(modelo);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "no se pudieron mostrar las ambulancias, error: " + e.toString());
        }
    }
    
    public void seleccionarAmbulancia(JTable tbA, JLabel id, JTextField placa, JComboBox tipo, JTextField capacidad, JTextField año){
      try{  int fila = tbA.getSelectedRow();
        
        if(fila>=0){
            id.setText(tbA.getValueAt(fila, 0).toString());
            placa.setText(tbA.getValueAt(fila, 1).toString());
            tipo.setSelectedItem(tbA.getValueAt(fila, 2).toString());
            capacidad.setText(tbA.getValueAt(fila, 3).toString());
            año.setText(tbA.getValueAt(fila, 4).toString());
        }
      }catch(Exception e){
          JOptionPane.showMessageDialog(null, "No se pudo seleccionar la fila, error: " + e.toString());
      }
    }
    
    public int modificarAmbulancia(JLabel id, JTextField placa, JComboBox tipo, JTextField capacidad, JTextField año){
        String consulta = "UPDATE ambulancia  SET PLACA = ?, TIPO = ?, CAPACIDAD = ?, AÑO = ? WHERE ID_AMBULANCIA=?";
        int idAmbulancia = -1;
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement psUpdate = conexion.prepareStatement(consulta)) {
            
            psUpdate.setString(1, placa.getText());
            psUpdate.setString(2,tipo.getSelectedItem().toString());
            psUpdate.setString(3,capacidad.getText());
            psUpdate.setString(4,año.getText());
            psUpdate.setString(5, id.getText());
            
            psUpdate.executeUpdate();
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo modificar la ambulancia, error: " + e.toString());
    }
            return idAmbulancia;
    }
    
    public void eliminiarAmbulancia(JLabel id){
        String consulta = "DELETE FROM ambulancia WHERE ID_AMBULANCIA = ?";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, id.getText());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
            
        }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "no se pudo eliminar la ambulancia, error: " + e.toString());
    }
    }
}
