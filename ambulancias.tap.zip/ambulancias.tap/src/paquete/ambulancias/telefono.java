package paquete.ambulancias;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.SQLException;

public class telefono {
    
    public int insertarTelefono(String telefono){
       
       String consulta = "INSERT INTO telefono (telefono_personal) VALUES (?);";
       int ultimoIdTelefono=-1;
       
       try(Connection conexion = Conexion.getInstancia().getConexion();
           PreparedStatement ps = conexion.prepareStatement(consulta, PreparedStatement.RETURN_GENERATED_KEYS)){
           
           ps.setString(1, telefono);
           ps.executeUpdate();
           
           try(ResultSet rs = ps.getGeneratedKeys()){
               if(rs.next()){
                   ultimoIdTelefono = rs.getInt(1);
               }
           }
           
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "error al insertar telefono, error: " + e.toString());
       }
    return ultimoIdTelefono;
    }
    
    public void modificarTelefono(JTextField numero, int idTelefono){
        String consulta = "UPDATE telefono t SET t.TELEFONO_PERSONAL = ? WHERE t.ID_TELEFONO= ?;";
        
        try (Connection conexion = Conexion.getInstancia().getConexion();
             PreparedStatement ps = conexion.prepareStatement(consulta)) {
            
            ps.setString(1, numero.getText());
            ps.setInt(2, idTelefono);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar telefono, error: " + e.toString());
        }
        
    }
    
}
